/*
 * Enumerado con los 4 palos de la baraja española
 */
package solitario.Core;

/**
 *
 * @author AEDI
 */
public enum Palos {
	OROS, COPAS, ESPADAS, BASTOS
}
